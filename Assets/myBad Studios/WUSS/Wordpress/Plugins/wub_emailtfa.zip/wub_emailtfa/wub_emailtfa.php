<?php

/*
Plugin Name: Wordpress For Unity Email Verification Expansion
Plugin URI: https://wuss.mybadstudios.com/
Description: Add the ability to require email verification codes on login
Version: 1.0
Network: true
Author: myBad Studios
Author URI: https://www.mybadstudios.com
*/

function activate_emailtfa(){
    global $wpdb;
    //store some information outside of well-known WP tables. Just as a precaution
    $table = 'CREATE TABLE IF NOT EXISTS '.$wpdb->prefix.'wub_emailtfacodes (
    		aiid bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    		gid bigint(20) UNSIGNED NOT NULL DEFAULT 0,
    		uid bigint(28) UNSIGNED NOT NULL DEFAULT 0,
    	    code varchar(64) NOT NULL DEFAULT "",
    	    expiration bigint(20) NOT NULL DEFAULT 0,
    	    PRIMARY KEY(aiid, gid, uid, code)
    	    );';

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($table);
}

function deactivate_emailexp()
{
}

function uninstall_emailexp(){
    //global $wpdb;
}
register_activation_hook( __FILE__,	'activate_emailtfa'	);
register_deactivation_hook( __FILE__,	'deactivate_emailexp'	);
register_uninstall_hook( __FILE__,	'uninstall_emailexp'	);

include_once(dirname(__FILE__) . "/classes/wubEmailTFA.class.php");
