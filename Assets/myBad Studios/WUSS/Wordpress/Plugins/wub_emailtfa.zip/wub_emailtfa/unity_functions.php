<?php

include_once(dirname(__FILE__) . "/../wub_login/settings.php");
include_once(dirname(__FILE__) . "/classes/wubEmailTFA.class.php");

function emailtfaGenerateTFAEntry() {
    global $current_user;

    $gid = Postedi('gid');
    $game_name = Posted('gamename');

    $tfa = new wubEmailTFA($gid, $current_user->ID);

    $code = $tfa->GenerateNewTFAEntry();
    if($code)
    {
        $response = $tfa->EmailPlayerTheirCode($game_name, $code);
        SendToUnity(SendField("success",true));
    }
    else {
        SendToUnity(PrintError("An error occurred generating the TFA code!"));
    }
}

function emailtfaValidateKey()
{
    global $current_user;

    $gid = Postedi('gid');
    $code = base64_decode(Posted('code'));

    $tfa = new wubEmailTFA($gid, $current_user->ID);
    if( $tfa->ValidateCode($code) )
    {
        SendToUnity(SendField("success","true"));
    }
    else {
        SendToUnity(PrintError("Code validation failed!"));
    }
}

