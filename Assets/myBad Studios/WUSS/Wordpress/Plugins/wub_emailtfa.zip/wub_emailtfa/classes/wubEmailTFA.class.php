<?php

if(!class_exists('wubEmailTFA')) {
    class wubEmailTFA
    {
        const
            TABLENAME = 'wub_emailtfacodes',
            TFADURATION = 600,
            DELETEEXPIREDKEYS = false; // keep to see how many people have played the game or remove to keep DB clean

        var $gid;
        var $uid;
        var $table_name;

        function __construct($gid, $uid)
        {
            global $wpdb;

            $this->gid = $gid;
            $this->uid = $uid;

            $this->table_name = $wpdb->prefix . wubEmailTFA::TABLENAME;
        }

        function GUID()
        {
            if (function_exists('com_create_guid') === true)
            {
                return trim(com_create_guid(), '{}');
            }

            return sprintf('%04X%04X-%04X-%04X-%04X-%04X%04X%04X', mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(16384, 20479), mt_rand(32768, 49151), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535));
        }

        public function GenerateNewTFAEntry()
        {
            global $wpdb;
            $code = $this->GUID();

            $result = $wpdb->insert(
                $this->table_name,
                array(
                    'gid' => $this->gid,
                    'uid' => $this->uid,
                    'code' => $code,
                    'expiration' => time() + wubEmailTFA::TFADURATION),
                array('%d', '%d', '%s', '%d')
                );

            if($result)
                return $code;

            return null;
        }

        function EmailPlayerTheirCode($code)
        {
            global $wpdb, $current_user;

            $game_name = $wpdb->get_var("SELECT post_title FROM $wpdb->posts WHERE ID = $this->gid");

            $from = "From: ".get_bloginfo('name')." <".get_bloginfo('admin_email').">";
            $email = $current_user->user_email;
            $subject = "Your Login Key For {$game_name}";
            $message = "
                <p>Your login key for {$game_name} is<br><strong>{$code}</strong></p>
                <p>This code will be valid for 10 minutes</p>
                <p>[My Company Name] @ 2024 ...</p>";
            $headers = array(
                $from,
                'Content-Type: text/html; charset=UTF-8'
            );

            $outcome = mail($email, $subject,$message,implode("\r\n", $headers));
            return $outcome;
        }

        function RevokeTFACode()
        {
            global $wpdb;
            $wpdb->delete(
                $this->table_name,
                array('gid'=>$this->gid, 'uid'=>$this->uid),
                array('%d','%d'));
        }

        function RevokeAllExpiredCodes()
        {
            global $wpdb;
            $time_now = time();

            $wpdb->query("DELETE FROM $this->table_name WHERE expiration < $time_now");
        }

        function ValidateCode($code)
        {
            global $wpdb;
            $response = $wpdb->get_var(
                "SELECT expiration FROM $wpdb->prefix" .
                wubEmailTFA::TABLENAME .
                " WHERE gid={$this->gid} AND uid={$this->uid} AND code='{$code}'" );
            if($response)
            {
                $time_now = time();
                $expiration_date = intval($response);
                if($time_now < $expiration_date)
                {
                    //do some cleanup. Remove all expired codes from the database
                    //not really the best place to do this but this automates it at least
                    $this->RevokeAllExpiredCodes();
                    return true;
                } else
                {
                    if(wubEmailTFA::DELETEEXPIREDKEYS)
                    {
                        //revoke this expired code
                        $this->RevokeTFACode();
                    }
                }
            }
            return false;
        }

    }
}